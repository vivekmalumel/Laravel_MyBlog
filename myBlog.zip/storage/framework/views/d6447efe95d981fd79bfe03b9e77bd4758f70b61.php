<?php $__env->startSection('content'); ?>
                <div class="row">
                <div class="col-lg-3">
                    <div class="card  text-center">
                        <div class="card-header bg-info">
                            POSTED
                        </div>
                        <div class="card-body">
                            <h2 class="text-center"><?php echo e($post_count); ?></h2>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3">
                    <div class="card  text-center">
                            <div class="card-header bg-danger">
                                TRASHED POSTS
                            </div>
                            <div class="card-body">
                            <h2 class="text-center"><?php echo e($trashed_count); ?></h2>
                            </div>
                        </div>

                </div>

                <div class="col-lg-3">
                        <div class="card  text-center">
                                <div class="card-header bg-success">
                                    USERS
                                </div>
                                <div class="card-body">
                                    <h2 class="text-center"><?php echo e($user_count); ?></h2>
                                </div>
                            </div>

                </div>

                <div class="col-lg-3">
                        <div class="card  text-center">
                                <div class="card-header bg-warning">
                                    CATRGORIES
                                </div>
                                <div class="card-body">
                                    <h2 class="text-center"><?php echo e($category_count); ?></h2>
                                </div>
                            </div>

                    </div>
            </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>