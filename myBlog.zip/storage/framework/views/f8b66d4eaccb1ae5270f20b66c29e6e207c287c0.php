<?php $__env->startSection('content'); ?>

    <div class="stunning-header stunning-header-bg-lightviolet">
        <div class="stunning-header-content">
            <h1 class="stunning-header-title">Tag: <?php echo e($tag->tag); ?></h1>
        </div>
    </div>

    <div class="container">
            <div class="row medium-padding120">
                <main class="main">

                    <div class="row">
                                <div class="case-item-wrap">
                                <?php $__currentLoopData = $tag->posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
                                        <div class="case-item">
                                            <div class="case-item__thumb">
                                                <img src="<?php echo e($post->featured); ?>" alt="<?php echo e($post->title); ?>">
                                            </div>
                                        <h6 class="case-item__title"><a href="<?php echo e(route('post.single',['slug'=>$post->slug])); ?>"><?php echo e($post->title); ?></a></h6>
                                        </div>
                                    </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                    </div>
                </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>