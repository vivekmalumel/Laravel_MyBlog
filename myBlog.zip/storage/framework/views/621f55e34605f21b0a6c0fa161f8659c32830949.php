<?php $__env->startSection('content'); ?>

    <?php echo $__env->make('admin.includes.errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="card card-default">
        <div class="card-header">
            <h2 class="card-title">Edit Your Profile</h2>
        </div>
        <div class="card-body">
        <form action="<?php echo e(route('user.profile.update')); ?>" method="post" enctype="multipart/form-data">
                <?php echo e(csrf_field()); ?>


                <div class="form-group">
                    <label for="name">Name</label>
                <input type="text" name="name" value="<?php echo e($user->name); ?>" class="form-control">
                </div>

                <div class="form-group">
                    <label for="email">Email</label>
                <input type="email" name="email" value="<?php echo e($user->email); ?>" class="form-control">
                </div>

                <div class="form-group">
                    <label for="avatar">Upload Avatar</label>
                <input type="file" name="avatar"  class="form-control">
                </div>

                <div class="form-group">
                    <label class="form-control"><input type="checkbox" id="change_pwd">Change Password</label>
                    <label for="password">New Password</label>
                <input type="password" name="password" id="new_password"  class="form-control" disabled="true">
                </div>
                <div class="form-group">
                    <label for="about">About</label>
                <textarea name="about" class="form-control" cols="30" rows="10"><?php echo e($user->profile->about); ?></textarea>
                </div>
                <div class="form-group">
                    <label for="facebook">Facebook Profile</label>
                <input type="text" name="facebook" value="<?php echo e($user->profile->facebook); ?>" class="form-control">
                </div>
                <div class="form-group">
                    <label for="youtube">Youtube Profile</label>
                <input type="text" name="youtube" value="<?php echo e($user->profile->youtube); ?>" class="form-control">
                </div>

                <div class="form-group">
                        <div class="text-center">
                            <button class="btn btn-success" type="submit">Update Profile</button>
                        </div>
                </div>

            </form>

        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>