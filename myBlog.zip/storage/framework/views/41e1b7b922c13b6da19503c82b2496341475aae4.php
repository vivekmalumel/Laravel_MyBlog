<?php $__env->startSection('content'); ?>
<div class="card card-default">
    <div class="card-header">
        <h2 class="card-title">My Posts</h2>
    </div>
    <div class="card-body">
<table class="table table-hover">
    <thead>
        <tr>
            <th>
                Image
            </th>

            <th>
                Title
            </th>
            <th>
                Edit
            </th>

            <th>
                Delete
            </th>
        </tr>
    </thead>
    <tbody>
    <?php if($posts->count()>0): ?>
        <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td style="vertical-align: middle;">
                <img src="<?php echo e($post->featured); ?>" alt="<?php echo e($post->title); ?>" height="100">
                </td>
                <td style="vertical-align: middle;">
                    <?php echo e($post->title); ?>

                </td>
                <td style="vertical-align: middle;">
                    <a href="<?php echo e(route('post.edit',['id'=> $post->id])); ?>" class="btn btn-xs btn-info">
                        <span class="text-white">Edit</span>
                    </a>
                </td>
                <td style="vertical-align: middle;">
                    <a href="<?php echo e(route('post.delete',['id'=> $post->id])); ?>" class="btn btn-xs btn-danger">
                                <span class="text-white" >Trash</span>
                    </a>
                </td>

            </tr>


        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php else: ?>
            <th colspan="5">No Posts Found</th>
    <?php endif; ?>
    </tbody>
</table>
</div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>