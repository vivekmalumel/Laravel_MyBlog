<?php $__env->startSection('content'); ?>
<div class="card card-default">
    <div class="card-header">
        <h2 class="card-title">All Tags</h2>
    </div>
    <div class="card-body">
<table class="table table-hover">
    <thead>
        <tr>
            <th>
                Tag
            </th>
            <th>
                Edit
            </th>

            <th>
                Delete
            </th>
        </tr>
    </thead>
    <tbody>
    <?php if($tags->count()>0): ?>
        <?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td style="vertical-align: middle;">
                    <?php echo e($tag->tag); ?>

                </td>
                <td style="vertical-align: middle;">
                    <a href="<?php echo e(route('tag.edit',['id'=> $tag->id])); ?>" class="btn btn-xs btn-info">
                        <span class="text-white">Edit</span>
                    </a>
                </td>
                <td style="vertical-align: middle;">
                    <a href="<?php echo e(route('tag.delete',['id'=> $tag->id])); ?>" class="btn btn-xs btn-danger">
                                <span class="text-white" >Delete</span>
                    </a>
                </td>

            </tr>


        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php else: ?>
            <th colspan="3" class="text-center">No Tags Yet!</th>
    <?php endif; ?>
    </tbody>
</table>
</div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>