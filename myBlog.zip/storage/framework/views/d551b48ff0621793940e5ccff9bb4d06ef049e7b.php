<?php $__env->startSection('content'); ?>

    <?php echo $__env->make('admin.includes.errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="card card-default">
        <div class="card-header">
            <h2 class="card-title">Edit Blog Settings</h2>
        </div>
        <div class="card-body">
        <form action="<?php echo e(route('settings.update')); ?>" method="post" enctype="multipart/form-data">
                <?php echo e(csrf_field()); ?>


                <div class="form-group">
                    <label for="site_name">Site Name</label>
                <input type="text" name="site_name" value="<?php echo e($settings->site_name); ?>" class="form-control">
                </div>

                <div class="form-group">
                    <label for="contact_email">Contact Email</label>
                    <input type="email" name="contact_email" value="<?php echo e($settings->contact_email); ?>" class="form-control">
                </div>
                <div class="form-group">
                        <label for="contact_number">Contact Number</label>
                        <input type="number" name="contact_number" value="<?php echo e($settings->contact_number); ?>" class="form-control">
                </div>
                <div class="form-group">
                        <label for="address">Content</label>
                <textarea name="address" rows="5" cols="5" id="address" class="form-control"><?php echo e($settings->address); ?></textarea>
                </div>
                <div class="form-group">
                        <div class="text-center">
                            <button class="btn btn-success" type="submit">Update Settings</button>
                        </div>
                </div>

            </form>

        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>